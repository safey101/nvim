-- ====================================
-- 基础设置
-- ====================================
vim.opt.showtabline = 2          -- 总是显示标签页
vim.opt.number = true            -- 显示行号
vim.opt.cursorline = true        -- 高亮当前行
vim.opt.termguicolors = true     -- 真彩色支持
vim.opt.signcolumn = "yes"       -- 始终显示符号列
vim.opt.syntax = "enable"        -- 语法高亮
vim.opt.ignorecase = true        -- 搜索忽略大小写
vim.opt.smartcase = true         -- 智能大小写
vim.opt.wrap = false             -- 不自动换行
vim.opt.clipboard:append("unnamedplus") -- 系统剪贴板
vim.opt.tabstop = 4              -- 制表符空格数
vim.opt.shiftwidth = 4           -- 自动缩进空格数
vim.opt.autoindent = true        -- 自动缩进
vim.opt.smartindent = true       -- 智能缩进
vim.opt.expandtab = true         -- 制表符转空格
vim.opt.mouse:append("a")        -- 鼠标支持
vim.opt.wildmenu = true          -- 命令补全菜单
vim.opt.encoding = "utf-8"       -- 编码设置
vim.opt.fileencoding = "utf-8"
vim.opt.undofile = true          -- 持久撤销
vim.opt.swapfile = true          -- 交换文件
vim.opt.backup = true            -- 备份文件
vim.opt.updatetime = 300         -- 更新间隔
vim.opt.timeoutlen = 500         -- 按键超时
vim.opt.splitright = true        -- 垂直分割右侧打开
vim.opt.splitbelow = true        -- 水平分割下方打开
vim.opt.filetype = "on"          -- 文件类型检测

-- ====================================
-- 按键绑定
-- ====================================
-- 基本键位
vim.keymap.set("i", "qq", "<ESC>")               -- 插入模式下qq退出插入模式
vim.keymap.set("n", " ", ":nohlsearch<CR>")      -- 空格取消搜索高亮
vim.keymap.set("n", "=", ":!go run %<CR>")       -- 运行当前Go文件
vim.keymap.set('n', '<F9>', ':NvimTreeToggle<CR>') -- 切换文件树

-- 实用快捷键
vim.keymap.set('n', '<leader>w', ':w<CR>', { desc = '保存文件' })
vim.keymap.set('n', '<leader>q', ':q<CR>', { desc = '退出' })
vim.keymap.set('n', '<leader>e', ':NvimTreeFocus<CR>', { desc = '聚焦文件树' })
vim.keymap.set('n', '<C-h>', '<C-w>h', { desc = '左窗口' })
vim.keymap.set('n', '<C-j>', '<C-w>j', { desc = '下窗口' })
vim.keymap.set('n', '<C-k>', '<C-w>k', { desc = '上窗口' })
vim.keymap.set('n', '<C-l>', '<C-w>l', { desc = '右窗口' })

-- ====================================
-- 插件配置
-- ====================================
require("plugins.plugins-setup")  -- 加载插件管理配置

-- 主题设置
vim.cmd('colorscheme tokyodark')

-- 注释插件
require('Comment').setup()

-- 禁用netrw
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1

-- 文件树配置
require("nvim-tree").setup({
    view = {
        width = 30,
        side = "left",
    },
    renderer = {
        highlight_git = true,
        icons = {
            show = {
                git = true,
                folder = true,
                file = true,
            },
            glyphs = {
                default = "",
                symlink = "",
                git = {
                    unstaged = "",
                    staged = "✓",
                    unmerged = "",
                    renamed = "➜",
                    untracked = "",
                    deleted = "",
                    ignored = "◌",
                },
            },
        },
    },
    filters = {
        dotfiles = false,
    },
})

-- ====================================
-- LSP配置
-- ====================================
require'mason'.setup{}
require'mason-lspconfig'.setup{
    ensure_installed = {
        'jdtls',     -- Java语言服务器
        'gopls',     -- Go
        'pyright',   -- Python
        'clangd',    -- C/C++
        'html',      -- HTML
        'denols',    -- JavaScript/TypeScript
        'volar',     -- Vue
        'yamlls',    -- YAML
        'cssls'      -- CSS
    },
    automatic_installation = true
}

local lspconfig = require'lspconfig'
local cmp_nvim_lsp = require('cmp_nvim_lsp')

-- 通用LSP配置
local on_attach = function(client, bufnr)
    local bufopts = { noremap=true, silent=true, buffer=bufnr }
    
    vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, bufopts)
    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, bufopts)
    vim.keymap.set('n', 'K', vim.lsp.buf.hover, bufopts)
    vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, bufopts)
    vim.keymap.set('n', '<C-k>', vim.lsp.buf.signature_help, bufopts)
    vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, bufopts)
    vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, bufopts)
    vim.keymap.set('n', 'gr', vim.lsp.buf.references, bufopts)
    vim.keymap.set('n', '<leader>f', function() vim.lsp.buf.format { async = true } end, bufopts)
end

local lsp_flags = {
    debounce_text_changes = 150,
}

-- 配置各语言服务器(除Java外)
local servers = {
    'gopls', 'pyright', 'clangd', 'html', 'denols', 'volar', 'yamlls', 'cssls','jdtls'
}

for _, lsp in ipairs(servers) do
    lspconfig[lsp].setup {
        on_attach = on_attach,
        flags = lsp_flags,
        capabilities = cmp_nvim_lsp.default_capabilities()
    }
end

-- ====================================

-- ====================================
-- 代码补全配置
-- ====================================
local cmp = require'cmp'
local luasnip = require'luasnip'

cmp.setup({
    snippet = {
        expand = function(args)
            luasnip.lsp_expand(args.body)
        end,
    },
    mapping = cmp.mapping.preset.insert({
        ['<C-b>'] = cmp.mapping.scroll_docs(-4),
        ['<C-f>'] = cmp.mapping.scroll_docs(4),
        ['<C-Space>'] = cmp.mapping.complete(),
        ['<C-e>'] = cmp.mapping.abort(),
        ['<CR>'] = cmp.mapping.confirm({ select = true }),
        ['<Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then
                luasnip.expand_or_jump()
            else
                fallback()
            end
        end, { 'i', 's' }),
        ['<S-Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then
                luasnip.jump(-1)
            else
                fallback()
            end
        end, { 'i', 's' })
    }),
    sources = cmp.config.sources({
        { name = 'nvim_lsp' },
        { name = 'luasnip' },
        { name = 'buffer' },
        { name = 'path' },
    }),
    window = {
        completion = cmp.config.window.bordered({
            border = 'rounded',
            winhighlight = "Normal:Normal,FloatBorder:FloatBorder,CursorLine:Visual,Search:None",
        }),
        documentation = cmp.config.window.bordered({
            border = 'rounded',
            winhighlight = "Normal:Normal,FloatBorder:FloatBorder,CursorLine:Visual,Search:None",
        }),
    },
    formatting = {
        fields = {'menu', 'abbr', 'kind'},
        format = function(entry, vim_item)
            vim_item.menu = ({
                nvim_lsp = '[LSP]',
                luasnip = '[Snippet]',
                buffer = '[Buffer]',
                path = '[Path]',
            })[entry.source.name]
            return vim_item
        end,
    }
})

-- ====================================
-- 颜色设置
-- ====================================
-- 调整补全菜单的颜色
vim.api.nvim_set_hl(0, 'CmpItemKind', { fg = '#7aa2f7' })
vim.api.nvim_set_hl(0, 'CmpItemAbbr', { fg = '#c0caf5' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatch', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzy', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemMenu', { fg = '#565f89' })
-- 调整选中项的颜色
vim.api.nvim_set_hl(0, 'CmpItemKindDefault', { fg = '#7aa2f7', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrDefault', { fg = '#c0caf5', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzyDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemMenuDefault', { fg = '#565f89', bg = '#1a1b26' })
-- 设置未选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLine', { bg = '#24283b', fg = '#c0caf5' })
-- 设置选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLineSel', { bg = '#1a1b26', fg = '#7aa2f7', bold = true })
-- 设置标签页区域填充部分的颜色
vim.api.nvim_set_hl(0, 'TabLineFill', { bg = '#1a1b26' })
-- 设置正常状态下的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLine', {
    bg = '#24283b',  -- 与未选中标签页背景色相近，保持协调
    fg = '#7aa2f7',  -- 与选中标签页文本强调色相近，突出显示
    bold = true      -- 文字加粗，增强视觉效果
})
-- 设置非当前窗口的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLineNC', {
    bg = '#1a1b26',  -- 与标签页填充部分背景色相同，统一整体风格
    fg = '#565f89'   -- 较暗的中性色，弱化非当前窗口状态栏
})
-- 设置注释的颜色
vim.api.nvim_set_hl(0, 'Comment', { fg = '#bb9af7', italic = true })
-- ====================================
-- 自动命令
-- ====================================
local autocmd = vim.api.nvim_create_autocmd

-- 保存时自动格式化
autocmd('BufWritePre', {
    pattern = '*',
    callback = function()
        vim.lsp.buf.format({ async = false })
    end,
})

-- 文件类型特定设置
autocmd('FileType', {
    pattern = { 'python', 'go', 'java' },
    callback = function()
        vim.opt_local.shiftwidth = 4
        vim.opt_local.tabstop = 4
        if vim.bo.filetype == 'java' then
            vim.opt_local.cindent = true
            vim.opt_local.foldmethod = "marker"
        end
    end,
})

