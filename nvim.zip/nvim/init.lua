--光标行 行号
vim.opt.number=true
vim.opt.cursorline=true	 --光标行突出
--外观-开启颜色支持
vim.opt.termguicolors=true 
vim.opt.signcolumn="yes"
vim.cmd('syntax enable')
--搜索
vim.opt.ignorecase=true --大小写不敏感
vim.opt.smartcase=true  --如果搜大写就是大写
--放置字符被包裹
vim.opt.wrap=false
--系统剪粘板
vim.opt.clipboard:append("unnamedplus") 
--缩进
vim.opt.tabstop=4
vim.opt.shiftwidth=4
vim.opt.autoindent=true
vim.opt.expandtab=true
--鼠标
vim.opt.mouse:append("a")
--按键绑定
vim.keymap.set("i","qq","<ESC>")  --qq代替ESC
vim.keymap.set("n"," ",":nohlsearch<CR>") --空格取消高亮
vim.keymap.set("n","<F10>",":NvimTreeToggle<CR>") --空格取消高亮
vim.cmd('nnoremap = :!go run %<CR>') --按=运行go run
--文件类型检测
vim.cmd('filetype plugin indent on')
--命令补全
vim.opt.wildmenu=true

--插件
require("plugins.plugins-setup")
vim.cmd('colorscheme deus') --设置主题
vim.cmd('hi Normal ctermbg=NONE guibg=NONE')
--配置注释插件
require('Comment').setup()
--配置nvimtree
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
require("nvim-tree").setup()
-- 启用 coc.nvim 自带的自动补全
vim.o.completeopt = 'menu,menuone,noselect'
vim.g.coc_global_extensions = {
    'coc-json',
    'coc-snippets',
    'coc-tsserver',
    'coc-eslint',
    'coc-go',
    'coc-vimlsp',
}
vim.g.go_language_server_command = {'gopls'} --启动go-lsp支持
vim.cmd('autocmd BufWritePre *.js,*.ts,*.tsx,*.jsx,*.go,*.py silent! call CocActionAsync("format")') -- 自动运行代码格式化
--coc配置
vim.api.nvim_create_augroup("CocGroup", {})
vim.api.nvim_create_autocmd("CursorHold", {
    group = "CocGroup",
    command = "silent call CocActionAsync('highlight')",
    desc = "Highlight symbol under cursor on CursorHold"
})
--设置coc快捷键
function _G.check_back_space()
    local col = vim.fn.col('.') - 1
    return col == 0 or vim.fn.getline('.'):sub(col, col):match('%s') ~= nil
end

local opts = {silent = true, noremap = true, expr = true, replace_keycodes = false}
vim.keymap.set("i", "<TAB>", 'coc#pum#visible() ? coc#pum#next(1) : v:lua.check_back_space() ? "<TAB>" : coc#refresh()', opts)
vim.keymap.set("i", "<S-TAB>", [[coc#pum#visible() ? coc#pum#prev(1) : "\<C-h>"]], opts)
vim.keymap.set("i", "<CR>", [[coc#pum#visible() ? coc#pum#confirm() : "\<C-g>u\<CR>\<c-r>=coc#on_enter()\<CR>"]], opts)
vim.keymap.set("i", "<c-j>", "<Plug>(coc-snippets-expand-jump)")
vim.keymap.set("i", "<c-space>", "coc#refresh()", {silent = true, expr = true})

