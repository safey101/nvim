-- ====================================
-- 基础设置
-- ====================================
-- 显示标签页编号，总是显示标签页
vim.opt.showtabline = 2
-- 显示行号
vim.opt.number = true
-- 突出显示光标所在行
vim.opt.cursorline = true
-- 开启真彩色支持
vim.opt.termguicolors = true
-- 始终显示符号列
vim.opt.signcolumn = "yes"
-- 开启语法高亮
vim.opt.syntax = "enable"
-- 搜索时忽略大小写
vim.opt.ignorecase = true
-- 当搜索模式包含大写字母时，进行大小写敏感搜索
vim.opt.smartcase = true
-- 防止文本自动换行
vim.opt.wrap = false
-- 支持系统剪贴板
vim.opt.clipboard:append("unnamedplus")
-- 缩进设置
vim.opt.tabstop = 4         -- 一个制表符显示的空格数
vim.opt.shiftwidth = 4      -- 自动缩进的空格数
vim.opt.autoindent = true   -- 自动缩进
vim.opt.smartindent = true  -- 智能缩进
vim.opt.expandtab = true    -- 将制表符转换为空格
-- 启用鼠标操作
vim.opt.mouse:append("a")
-- 命令补全菜单
vim.opt.wildmenu = true
-- 编码设置
vim.opt.encoding = "utf-8"
vim.opt.fileencoding = "utf-8"

-- ====================================
-- 按键绑定
-- ====================================
-- 在插入模式下，输入 qq 替代 ESC 键
vim.keymap.set("i", "qq", "<ESC>")
-- 在正常模式下，按空格取消搜索高亮
vim.keymap.set("n", " ", ":nohlsearch<CR>")
-- 在正常模式下，按 = 运行当前 Go 文件
vim.keymap.set("n", "=", ":!go run %<CR>")
-- 在正常模式下，按 F9 切换文件树
vim.keymap.set('n', '<F9>', ':NvimTreeToggle<CR>')

-- ====================================
-- 文件类型检测
-- ====================================
-- 开启文件类型插件和缩进检测
vim.opt.filetype = "plugin"
vim.opt.filetype = "indent"

-- ====================================
-- 插件配置
-- ====================================
-- 加载插件设置
require("plugins.plugins-setup")
-- 设置主题
vim.cmd('colorscheme tokyodark')
-- 配置注释插件
require('Comment').setup()
-- 禁用默认的 netrw 文件浏览器
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
-- 配置 nvim-tree 文件树插件
require("nvim-tree").setup()

-- ====================================
-- LSP 配置
-- ====================================
-- 初始化 Mason 插件管理器
require'mason'.setup{}
-- 配置 Mason LSP 配置器
require'mason-lspconfig'.setup{
    ensure_installed = {
        'gopls',      -- Go 语言 LSP 服务器
        'pyright',    -- Python 语言 LSP 服务器
        'clangd',     -- C/C++ 语言 LSP 服务器
        'html',       -- HTML 语言 LSP 服务器
        'denols',     -- JavaScript/TypeScript 语言 LSP 服务器
        'volar',      -- Vue 语言 LSP 服务器
        'yamlls',     -- YAML 语言 LSP 服务器
        'cssls'       -- CSS 语言 LSP 服务器
    },
    automatic_installation = true
}

-- 引入 lspconfig 模块
local lspconfig = require'lspconfig'

-- 配置各个语言的 LSP 服务器
lspconfig.gopls.setup{}
lspconfig.pyright.setup{}
lspconfig.clangd.setup{}
lspconfig.html.setup{}
lspconfig.denols.setup{}
lspconfig.volar.setup{}
lspconfig.yamlls.setup{}
lspconfig.cssls.setup{}

-- ====================================
-- 代码补全配置
-- ====================================
-- 引入 cmp 和 luasnip 模块
local cmp = require'cmp'
local luasnip = require'luasnip'

-- 配置 cmp 代码补全插件
cmp.setup({
    snippet = {
        expand = function(args)
            luasnip.lsp_expand(args.body)
        end,
    },
    mapping = cmp.mapping.preset.insert({
        ['<C-b>'] = cmp.mapping.scroll_docs(-4),
        ['<C-f>'] = cmp.mapping.scroll_docs(4),
        ['<C-Space>'] = cmp.mapping.complete(),
        ['<C-e>'] = cmp.mapping.abort(),
        ['<CR>'] = cmp.mapping.confirm({ select = true }),
        -- 使用 Tab 选择下一个补全项
        ['<Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then
                luasnip.expand_or_jump()
            else
                fallback()
            end
        end, { 'i', 's' }),
        -- 使用 Shift + Tab 选择上一个补全项
        ['<S-Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then
                luasnip.jump(-1)
            else
                fallback()
            end
        end, { 'i', 's' })
    }),
    sources = cmp.config.sources({
        { name = 'nvim_lsp' }, --lsp补全
        { name = 'luasnip' }, --代码片段补全
        { name = 'buffer' }, --缓冲区补全
        { name = 'path' }, --缓冲区内容补全
    }),
    window = {
        completion = cmp.config.window.bordered({
            border = 'rounded',
            source = 'always',
            header = '',
            prefix = ''
        }),
        documentation = cmp.config.window.bordered({
            border = 'rounded'
        })
    }
})

-- ====================================
-- 颜色设置
-- ====================================
-- 调整补全菜单的颜色
vim.api.nvim_set_hl(0, 'CmpItemKind', { fg = '#7aa2f7' })
vim.api.nvim_set_hl(0, 'CmpItemAbbr', { fg = '#c0caf5' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatch', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzy', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemMenu', { fg = '#565f89' })
-- 调整选中项的颜色
vim.api.nvim_set_hl(0, 'CmpItemKindDefault', { fg = '#7aa2f7', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrDefault', { fg = '#c0caf5', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzyDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemMenuDefault', { fg = '#565f89', bg = '#1a1b26' })
-- 设置未选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLine', { bg = '#24283b', fg = '#c0caf5' })
-- 设置选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLineSel', { bg = '#1a1b26', fg = '#7aa2f7', bold = true })
-- 设置标签页区域填充部分的颜色
vim.api.nvim_set_hl(0, 'TabLineFill', { bg = '#1a1b26' })
-- 设置正常状态下的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLine', {
    bg = '#24283b',  -- 与未选中标签页背景色相近，保持协调
    fg = '#7aa2f7',  -- 与选中标签页文本强调色相近，突出显示
    bold = true      -- 文字加粗，增强视觉效果
})
-- 设置非当前窗口的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLineNC', {
    bg = '#1a1b26',  -- 与标签页填充部分背景色相同，统一整体风格
    fg = '#565f89'   -- 较暗的中性色，弱化非当前窗口状态栏
})
-- 设置注释的颜色
vim.api.nvim_set_hl(0, 'Comment', { fg = '#bb9af7', italic = true })
