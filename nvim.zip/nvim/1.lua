--显示标签页编号
vim.opt.showtabline = 2 -- 总是显示标签页
--光标行 行号
vim.opt.number=true
vim.opt.cursorline=true	 --光标行突出
--外观-开启颜色支持
vim.opt.termguicolors=true 
vim.opt.signcolumn="yes"
vim.cmd('syntax enable')
--搜索
vim.opt.ignorecase=true --大小写不敏感
vim.opt.smartcase=true  --如果搜大写就是大写
--放置字符被包裹
vim.opt.wrap=false
--系统剪粘板
vim.opt.clipboard:append("unnamedplus") 
--缩进
vim.opt.tabstop=4
vim.opt.shiftwidth=4
vim.opt.autoindent=true
vim.opt.smartindent=true
vim.opt.expandtab=true
--鼠标
vim.opt.mouse:append("a")
--按键绑定
vim.keymap.set("i","qq","<ESC>")  --qq代替ESC
vim.keymap.set("n"," ",":nohlsearch<CR>") --空格取消高亮
vim.cmd('nnoremap = :!go run %<CR>') --按=运行go run
--文件类型检测
vim.cmd('filetype plugin indent on')
--命令补全
vim.opt.wildmenu=true
--编码
vim.cmd('set encoding=utf-8')
vim.cmd('set fileencoding=utf-8')

--插件
require("plugins.plugins-setup")
vim.cmd('colorscheme tokyodark') --设置主题
--vim.cmd('hi Normal ctermbg=NONE guibg=NONE')
--配置注释插件
require('Comment').setup()
--配置nvimtree
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
vim.keymap.set('n', '<F9>', ':NvimTreeToggle<CR>')
require("nvim-tree").setup()

--lsp配置
require'mason'.setup{}
require'mason-lspconfig'.setup{
    ensure_installed = {
        'gopls',
        'pyright',
        'clangd',
        'html',
        'denols',
        'volar',
        'yamlls',
        'cssls'
    },
    automatic_installation = true
}

local lspconfig = require'lspconfig'

local capabilities = require('cmp_nvim_lsp').default_capabilities()

-- 配置 Go 语言的 LSP 服务器
lspconfig.gopls.setup{
    capabilities = capabilities
}
-- 配置 Python 语言的 LSP 服务器
lspconfig.pyright.setup{
    capabilities = capabilities
}
-- 配置 C 语言的 LSP 服务器
lspconfig.clangd.setup{
    capabilities = capabilities
}
-- 配置 HTML 语言的 LSP 服务器
lspconfig.html.setup{
    capabilities = capabilities
}
-- 配置 JavaScript/TypeScript 语言的 LSP 服务器
lspconfig.denols.setup{
    capabilities = capabilities
}
-- 配置 Vue 语言的 LSP 服务器
lspconfig.volar.setup{
    capabilities = capabilities
}
-- 配置 YAML 语言的 LSP 服务器
lspconfig.yamlls.setup{
    capabilities = capabilities
}
-- 配置 CSS 语言的 LSP 服务器
lspconfig.cssls.setup{
    capabilities = capabilities
}

-- 代码补全配置
local cmp = require'cmp'
local luasnip = require'luasnip'

cmp.setup({
    snippet = {
        expand = function(args)
            luasnip.lsp_expand(args.body)
        end,
    },
    mapping = cmp.mapping.preset.insert({
        ['<C-b>'] = cmp.mapping.scroll_docs(-4),
        ['<C-f>'] = cmp.mapping.scroll_docs(4),
        ['<C-Space>'] = cmp.mapping.complete(),
        ['<C-e>'] = cmp.mapping.abort(),
        ['<CR>'] = cmp.mapping.confirm({ select = true }),
        -- 使用 Tab 选择下一个补全项
        ['<Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then
                luasnip.expand_or_jump()
            else
                fallback()
            end
        end, { 'i', 's' }),
        -- 使用 Shift + Tab 选择上一个补全项
        ['<S-Tab>'] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then
                luasnip.jump(-1)
            else
                fallback()
            end
        end, { 'i', 's' })
    }),
    sources = cmp.config.sources({
        { name = 'nvim_lsp' },
        { name = 'luasnip' },
    }, {
        { name = 'buffer' },
        { name = 'path' },
    })
})

-- 调整补全菜单的颜色
vim.api.nvim_set_hl(0, 'CmpItemKind', { fg = '#7aa2f7' })
vim.api.nvim_set_hl(0, 'CmpItemAbbr', { fg = '#c0caf5' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatch', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzy', { fg = '#bb9af7', bold = true })
vim.api.nvim_set_hl(0, 'CmpItemMenu', { fg = '#565f89' })
-- 调整选中项的颜色
vim.api.nvim_set_hl(0, 'CmpItemKindDefault', { fg = '#7aa2f7', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrDefault', { fg = '#c0caf5', bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemAbbrMatchFuzzyDefault', { fg = '#bb9af7', bold = true, bg = '#1a1b26' })
vim.api.nvim_set_hl(0, 'CmpItemMenuDefault', { fg = '#565f89', bg = '#1a1b26' })

-- 设置未选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLine', { bg = '#24283b', fg = '#c0caf5' })
-- 设置选中标签页的颜色
vim.api.nvim_set_hl(0, 'TabLineSel', { bg = '#1a1b26', fg = '#7aa2f7', bold = true })
-- 设置标签页区域填充部分的颜色
vim.api.nvim_set_hl(0, 'TabLineFill', { bg = '#1a1b26' })

-- 设置正常状态下的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLine', {
    bg = '#24283b',  -- 与未选中标签页背景色相近，保持协调
    fg = '#7aa2f7',  -- 与选中标签页文本强调色相近，突出显示
    bold = true      -- 文字加粗，增强视觉效果
})

-- 设置非当前窗口的状态栏颜色
vim.api.nvim_set_hl(0, 'StatusLineNC', {
    bg = '#1a1b26',  -- 与标签页填充部分背景色相同，统一整体风格
    fg = '#565f89'   -- 较暗的中性色，弱化非当前窗口状态栏
})

-- 设置注释的颜色
vim.api.nvim_set_hl(0, 'Comment', { fg = '#bb9af7', italic = true })
