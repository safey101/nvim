local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    -- 使用镜像源克隆 packer.nvim
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com.cnpmjs.org/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
    -- 设置 GitHub 镜像源
    local github_proxy = "https://github.com.cnpmjs.org/"
    local original_use = use
    use = function(spec)
        if type(spec) == 'string' then
            spec = { spec }
        end
        if spec[1]:find('github.com') then
            spec[1] = spec[1]:gsub('github.com', 'github.com.cnpmjs.org')
        end
        original_use(spec)
    end

    use 'wbthomason/packer.nvim' -- 插件 manager
    use { "tiagovla/tokyodark.nvim" } -- 主题
    use {"rose-pine/neovim"}
    use {"rebelot/kanagawa.nvim"}
    use 'nvim-tree/nvim-tree.lua' -- 标签列表
    use 'yaocccc/nvim-hlchunk' -- 缩进线
    use 'fatih/vim-go' -- go 主要插件
    use 'preservim/tagbar' -- 代码跳转
    use 'jiangmiao/auto-pairs' -- 符号补全
    use 'numToStr/Comment.nvim' -- 注释
    use 'mg979/vim-visual-multi' -- 多光标
    use {"euclio/vim-markdown-composer",run = "cargo build --release"} --markdown插件
    use {"gelguy/wilder.nvim",config = function()require('wilder').setup({ modes = { ':', '/', '?' } })end}
    -- lsp
    use {
        'williamboman/mason.nvim', -- lsp 服务器管理工具
        'williamboman/mason-lspconfig.nvim', -- 连接 mason 和 nvim-lspconfig
        'neovim/nvim-lspconfig', -- lsp 核心配置文件
    }
    -- 代码补全相关插件
    use 'hrsh7th/cmp-nvim-lsp' -- 补全代码 lsp
    use 'hrsh7th/nvim-cmp'
    use 'hrsh7th/cmp-buffer'
    use 'hrsh7th/cmp-path'
    use 'saadparwaiz1/cmp_luasnip'
    use 'L3MON4D3/LuaSnip'

    if packer_bootstrap then
        require('packer').sync()
    end
end)
    
