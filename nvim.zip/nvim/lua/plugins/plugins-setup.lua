local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'--插件manager
  use { "tiagovla/tokyodark.nvim" } --主题
  use 'nvim-tree/nvim-tree.lua' --标签列表
  use {'neoclide/coc.nvim', branch = 'release'} --coc代码提示
  use 'yaocccc/nvim-hlchunk' --缩进线
  use 'fatih/vim-go' --go主要插件
  use 'preservim/tagbar' --代码跳转
  use 'jiangmiao/auto-pairs' --符号补全
  use 'numToStr/Comment.nvim'--注释
  use 'honza/vim-snippets'--代码片

  if packer_bootstrap then
    require('packer').sync()
  end
end)
