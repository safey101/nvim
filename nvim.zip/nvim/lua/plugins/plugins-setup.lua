local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'--插件manager
  use { "tiagovla/tokyodark.nvim" } --主题
  use 'nvim-tree/nvim-tree.lua' --标签列表
  use 'yaocccc/nvim-hlchunk' --缩进线
  use 'fatih/vim-go' --go主要插件
  use 'preservim/tagbar' --代码跳转
  use 'jiangmiao/auto-pairs' --符号补全
  use 'numToStr/Comment.nvim'--注释
  --lsp
  use {
  'williamboman/mason.nvim', --lsp服务器管理工具
  'williamboman/mason-lspconfig.nvim', --连接mason和nvim-lspconfig
  'neovim/nvim-lspconfig', --lsp核心配置文件
}
 -- 代码补全相关插件
    use 'hrsh7th/cmp-nvim-lsp' --补全代码lsp
    use 'hrsh7th/nvim-cmp'
    use 'hrsh7th/cmp-buffer'
    use 'hrsh7th/cmp-path'
    use 'saadparwaiz1/cmp_luasnip'
    use 'L3MON4D3/LuaSnip'

  if packer_bootstrap then
    require('packer').sync()
  end
end)
